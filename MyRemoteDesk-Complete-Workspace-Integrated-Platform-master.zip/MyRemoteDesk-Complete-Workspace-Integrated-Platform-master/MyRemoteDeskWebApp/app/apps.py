from django.apps import AppConfig


class App(AppConfig):
    name = 'app'
